import os
import sys
import json
import re

def render_report(template_path, json_data_path, output_path):
    print(f"Reading template from: {template_path}")
    with open(template_path, 'r', encoding='utf-8') as f:
        html_content = f.read()

    print(f"Reading data from: {json_data_path}")
    with open(json_data_path, 'r', encoding='utf-8') as f:
        data = json.load(f)

    print("Populating placeholders...")
    # Render direct text placeholders
    for key, val in data.items():
        placeholder = f"{{{{{key.upper()}}}}}"
        # If val is list or dict, we convert it to JSON-like string for JavaScript/Chart.js
        if isinstance(val, (list, dict)):
            val_str = json.dumps(val, ensure_ascii=False)
            html_content = html_content.replace(placeholder, val_str)
        else:
            html_content = html_content.replace(placeholder, str(val))

    # Create parent directories for output if they don't exist
    output_dir = os.path.dirname(output_path)
    if output_dir and not os.path.exists(output_dir):
        print(f"Creating directory: {output_dir}")
        os.makedirs(output_dir, exist_ok=True)

    print(f"Writing final HTML report to: {output_path}")
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(html_content)

    print("Success! HTML report generated successfully.")

if __name__ == "__main__":
    if len(sys.argv) < 4:
        print("Usage: python render.py <template_path> <json_data_path> <output_path>")
        sys.exit(1)
        
    template_path = sys.argv[1]
    json_data_path = sys.argv[2]
    output_path = sys.argv[3]
    
    render_report(template_path, json_data_path, output_path)
