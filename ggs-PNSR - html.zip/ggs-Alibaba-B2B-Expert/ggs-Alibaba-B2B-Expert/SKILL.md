---
name: ggs-Alibaba-B2B-Expert-html
description: |
  Industry-adaptive Alibaba.com B2B market intelligence and global export strategy skill for Vietnam manufacturers, exporters, and B2B brands.

  When to Use:
    - Alibaba market reports for any requested industry
    - Vietnam export analysis for any requested industry
    - Supplier landscape research on Alibaba.com
    - Supplier list Alibaba / Alibaba supplier analysis
    - Competitor benchmarking and factory benchmark analysis
    - Pricing intelligence, MOQ analysis, lead-time comparison
    - SEO keyword mapping for Alibaba.com listings
    - Product trend analysis and product benchmark reports
    - Product image benchmark analysis
    - Premium interactive HTML export reports using the provided reference template
    - DOCX export reports using a provided or inferred template structure
    - Vietnamese requests: bao cao thi truong Alibaba, phan tich xuat khau, nghien cuu nganh hang, phan tich doi thu, phan tich supplier, bao cao B2B, bao cao HTML, bao cao xuat khau

  Core Rule:
    - Always identify the user's requested industry first.
    - Treat the bundled ceramics report as a reference sample for structure, depth, visual style, and analysis quality only.
    - Do not restrict reports to ceramics.
    - For every requested industry, build a fresh industry profile, benchmark logic, pricing logic, SEO map, and export strategy.
    - Default report mode is full-intelligence-report.
    - Default HTML style is premium-visual.
    - Every completed report must be exported as an HTML file unless the user explicitly requests another format only.
enabled: true
---

# B2B Market Intelligence Pro

Industry-adaptive Alibaba.com export intelligence toolkit for Vietnam suppliers. Use it to create full supplier research, competitor benchmarking, pricing intelligence, SEO maps, product benchmarks, image benchmarks, and export strategy reports for whichever industry the user requests.

The bundled ceramics HTML is a finished sample report. It is not the only supported industry and must not cause the agent to force every task into ceramics.

Default deliverable: a premium responsive HTML report file. Do not finish a report-generation task with only chat text when file creation is available.

---

## Part 1: Industry Profile Builder

### Core Principle

Build a fresh industry profile for every requested industry. The user may ask for furniture, apparel, food, handicrafts, packaging, machinery, beauty, home decor, agricultural products, or any other export category. The agent must adapt the report to that industry instead of using a fixed industry pack.

### Reference Sample Role

| File | Role | Important Rule |
|------|------|----------------|
| `b2b-reports/Bao_cao_mau_Alibaba.html` | Workspace sample export template | If this file exists in the workspace it becomes the primary concrete export template — replace placeholders with industry data and save outputs to `b2b-reports/` |
| `assets/templates/Gom_su_VietNam.html` | Reference sample for premium HTML structure, visual density, section depth, dashboard layout, table style, and analysis quality | Use as a visual model to adapt, not as a ceramics-only constraint |

### Industry Identification Flow

| Step | Action |
|------|--------|
| 1 | Identify the requested industry from the user prompt, product name, target market, attached files, or examples |
| 2 | Create an industry slug, e.g. `noi-that-viet-nam`, `may-mac-viet-nam`, `thu-cong-my-nghe-viet-nam` |
| 3 | Define the product taxonomy for that industry |
| 4 | Define benchmark criteria specific to that industry |
| 5 | Define pricing units, MOQ logic, and sourcing assumptions for that industry |
| 6 | Define compliance/certification topics relevant to that industry |
| 7 | Define SEO keyword themes and buyer-intent keywords for that industry |
| 8 | Generate the report using the premium reference structure, replacing all sample data with verified data for the requested industry |

### Dynamic Industry Profile Schema

For every report, create this mental profile before writing:

| Field | Required Content |
|-------|------------------|
| Industry slug | Lowercase identifier for the requested industry |
| Product scope | Exact product categories covered in the report |
| Target buyers | Importers, wholesalers, retailers, distributors, brands, hotels, factories, or project buyers |
| Supplier benchmark criteria | Industry-specific credibility, capability, product, quality, and export-readiness factors |
| Product benchmark criteria | Materials, design, use cases, variants, customization, packaging, visuals, and claims |
| Pricing units | Units that make sense for the industry, such as piece, set, kg, ton, carton, sqm, cbm, container |
| MOQ logic | How MOQ is normally expressed and compared in the industry |
| Compliance focus | Certifications, safety rules, documentation, and restricted claims that are relevant and visible |
| SEO themes | Core product, material, process, origin, buyer-intent, and target-market keywords |
| Export strategy angle | Positioning, product focus, Alibaba listing strategy, RFQ strategy, sample strategy, risk controls |

### Example Industry Adaptation

If the user asks for furniture, do not use ceramics criteria. Build furniture criteria such as:

| Area | Furniture-Specific Logic |
|------|--------------------------|
| Product taxonomy | indoor furniture, outdoor furniture, wooden furniture, rattan furniture, hotel furniture, restaurant furniture, office furniture, bedroom/living/dining categories |
| Materials | solid wood, plywood, MDF, veneer, bamboo, rattan, metal frame, upholstery, foam, fabric, leather alternatives |
| Pricing units | piece, set, carton, cbm, container, FOB unit price if visible |
| MOQ | pieces, sets, mixed container, full container load when visible |
| Compliance | FSC, BSCI, ISO, CARB P2, TSCA Title VI, fire retardant, OEKO-TEX for upholstery only if visible |
| Benchmark | factory scale, OEM/ODM, project experience, packaging, KD/flat-pack capability, customization, export markets |
| SEO | Vietnam furniture supplier, wooden furniture manufacturer, custom hotel furniture, rattan outdoor furniture, OEM furniture factory |

---

## Part 2: Execution Modes

### Default Mode

Always use `full-intelligence-report` for report generation requests unless the user explicitly asks for a quick, simplified, or lightweight output.

Always use `premium-visual` as the default HTML style unless the user explicitly requests simple HTML.

### Mode Table

| Mode | Use When | Minimum Evidence | Output Depth |
|------|----------|------------------|--------------|
| `quick-analysis` | User explicitly asks for a fast snapshot | 3+ suppliers, 5+ products when available | Key findings, price corridor, risks, next actions |
| `standard-report` | User explicitly asks for a medium report | 5-10 suppliers, 10+ products when available | Supplier landscape, pricing, product benchmark, SEO map, strategy |
| `full-intelligence-report` | Default for reports, HTML, DOCX, dashboards, or competitor analysis | Prefer 10+ suppliers, 20+ products when available | Full industry report, premium template-based HTML/DOCX, charts/tables, source list |

### Full-Intelligence Report Must Include

- Supplier landscape analysis.
- Competitor positioning analysis.
- Pricing intelligence tables.
- Product benchmark analysis.
- Factory benchmark analysis when data exists.
- Product image benchmark analysis when image/listing evidence exists.
- SEO keyword mapping.
- Buyer persona analysis.
- Channel strategy.
- Alibaba optimization recommendations.
- Export strategy recommendations.
- Market opportunity analysis.
- Risk analysis.
- Sourcing intelligence.
- Source references.
- Premium visual deliverables in requested formats.

### Supported Formats

| Format | Default Behavior |
|--------|------------------|
| Markdown | Use structured report sections and tables |
| Responsive HTML | Default required deliverable; use premium-visual template style |
| DOCX | Use template-first document structure when a DOCX template is available |

Do not downgrade to `quick-analysis`, `standard-report`, `simple-html`, or `advanced-interactive` unless the user explicitly requests a simplified output.

### HTML File Output Contract

For every report-generation request, create a physical `.html` file unless the user explicitly asks for Markdown-only, DOCX-only, or no file output.

| Requirement | Instruction |
|-------------|-------------|
| Output format | Always create a premium responsive HTML file by default |
| File naming | Use a readable industry slug, e.g. `Bao_cao_nganh_Noi_that_Alibaba.html`, `Bao_cao_nganh_May_mac_Alibaba.html` |
| Output folder | Prefer `b2b-reports/` in the current workspace or the platform-provided output directory |
| Output creation | Automatically create `b2b-reports/` if it does not exist and save the report there |
| Template | Use the workspace sample `b2b-reports/Bao_cao_mau_Alibaba.html` as the primary export template when available; otherwise use `assets/templates/Gom_su_VietNam.html` as the visual reference |
| Final response | Include the saved HTML file path and a short completion note |
| No silent completion | Do not stop after analysis; the task is complete only when the HTML file exists or the environment prevents file creation |

If the environment prevents writing files, explain the blocker and provide the complete HTML content as a fallback.

### Data Freshness and Export Contract

- Never reuse prior session or cached report content; rebuild every report from verified current sources.
- Verify that supplier links, product listings, prices, and certifications are refreshed for each new report.
- Automatically write the HTML report file as part of the final response flow, without requiring a separate manual save step.

---

## Part 3: Research Workflow

### Data Collection

1. Confirm or infer industry, product scope, origin country, target market, buyer segment, language, and output format.
2. Build the dynamic industry profile before writing.
3. Use `b2b-reports/Bao_cao_mau_Alibaba.html` as the concrete export template when present; otherwise use the ceramics visual reference `assets/templates/Gom_su_VietNam.html` as the premium visual model for output.
4. Browse or verify current sources for Alibaba.com suppliers, product listings, pricing, MOQ, certifications, lead times, and visible credibility signals.
5. Capture source URLs for all supplier, product, pricing, certification, and market claims.
6. Preserve original company names, listing titles, URLs, countries, certifications, MOQ, price ranges, and lead times exactly as found.

### Supplier Intelligence

| Required Field | Notes |
|----------------|-------|
| Supplier name | Preserve original spelling |
| Alibaba URL | Do not invent or shorten fake URLs |
| Country/region | Record exactly as shown |
| Product focus | Product categories from the requested industry |
| Alibaba tenure | Include only if visible |
| Verification status | Include only if visible |
| Certifications | Preserve exact certification names only if visible |
| MOQ | Include unit and caveat |
| Price range | Include unit, MOQ, and visible Incoterms if available |
| Lead time | Include only if visible |
| Strengths/risks | Separate verified facts from analysis |

### Product Benchmarking

Benchmark products using attributes that belong to the requested industry. Do not reuse ceramics attributes unless the requested industry is ceramics.

For every industry, compare:

- Product type and subcategory.
- Materials, process, specifications, and variants.
- Use case and buyer segment.
- Customization/OEM/ODM options.
- Packaging and export readiness.
- Listing image quality and product presentation.
- Compliance or certification claims only when visible.
- MOQ, price range, lead time, and sample policy when visible.

### Pricing Intelligence

Build pricing by the correct industry unit. Examples:

| Industry Type | Possible Units |
|---------------|----------------|
| Furniture | piece, set, carton, cbm, container |
| Apparel | piece, set, size/color SKU, carton |
| Food/agriculture | kg, ton, bag, carton, container |
| Packaging | piece, roll, sqm, carton, ton |
| Machinery | unit, set, line, spare part package |
| Ceramics | piece, set, carton, pallet |

Always include MOQ and confidence notes. If prices are hidden, state `Unavailable`.

### SEO Mapping

Map keywords by the requested industry:

| Keyword Type | Required Logic |
|--------------|----------------|
| Core product | Main product terms buyers search |
| Origin/value | Vietnam, Vietnamese, handmade, OEM, factory, manufacturer, supplier when relevant |
| Buyer intent | wholesale, bulk, custom, private label, OEM, ODM, project, distributor |
| Material/process | Industry-specific material and process terms |
| Market/use case | Retail, hotel, restaurant, outdoor, industrial, food service, construction, etc. |
| Compliance | Only include compliance keywords that are relevant and verified or clearly framed as target keywords |

---

## Part 4: Premium Template-Based Output

### Template Priority

If a designed HTML, DOCX, or other report template is available, use it as the primary output structure. Do not redesign the report unless the user explicitly asks for a redesign.

For stored templates or workspace-provided samples, prefer `b2b-reports/Bao_cao_mau_Alibaba.html` if present in the workspace; otherwise look under `assets/templates/`.

| Template | Role | Use |
|----------|------|-----|
| `b2b-reports/Bao_cao_mau_Alibaba.html` | Workspace sample template | Use this concrete file as the export template when it exists; replace placeholders with industry data and save the final `.html` into `b2b-reports/` |
| `assets/templates/Gom_su_VietNam.html` | Finished reference sample | Study and preserve its report depth, visual density, section style, tables, dashboard cards, and navigation pattern |

### Mandatory Adaptation Rule

When using the reference sample for a new industry:

1. Replace the report title, meta text, sidebar section names if needed, and all industry wording.
2. Replace all ceramics-specific suppliers, products, market statements, chart values, keywords, and recommendations.
3. Rebuild benchmark criteria for the requested industry.
4. Rebuild pricing units and MOQ logic for the requested industry.
5. Rebuild SEO keyword map for the requested industry.
6. Rebuild export strategy for the requested industry.
7. Keep the premium visual structure and interaction style.

### Premium HTML Requirements

- Premium dashboard layout.
- Responsive sections.
- Executive summary cards.
- Advanced tables.
- Visual benchmark blocks.
- Image comparison sections when data exists.
- Pricing intelligence sections.
- Keyword heatmaps when supported by data.
- Modern typography.
- Print-friendly formatting.
- Branded visual structure.
- Interactive navigation when supported.

### Template Rules

| Rule | Instruction |
|------|-------------|
| Preserve design | Keep layout, typography, colors, sidebar, headers, footers, spacing, cards, chart containers, and table styles |
| Replace data | Replace placeholders, sample text, old supplier data, chart values, and conclusions with verified research data |
| Adapt industry | Rewrite all product taxonomy, benchmark logic, pricing logic, SEO logic, and export strategy for the requested industry |
| Keep structure | Keep section depth and premium feel; section names may change to fit the requested industry |
| Handle missing data | Use `Unavailable` and explain the limitation |
| Treat sample as sample | Re-verify every supplier, price, market figure, certification, and source claim in completed sample templates |
| Avoid fake content | Do not invent suppliers, prices, certifications, URLs, charts, or product claims |

### Recommended Placeholder Map

Use or infer these fields when editing templates:

| Placeholder | Meaning |
|-------------|---------|
| `{{report_title}}` | Report title |
| `{{date}}` | Report date |
| `{{industry_slug}}` | Requested industry slug |
| `{{product_scope}}` | Product/category scope |
| `{{target_markets}}` | Target export markets |
| `{{executive_summary}}` | Summary findings |
| `{{supplier_table}}` | Supplier landscape table |
| `{{pricing_table}}` | Pricing intelligence table |
| `{{product_benchmark}}` | Product comparison |
| `{{image_benchmark}}` | Product image benchmark |
| `{{seo_keywords}}` | SEO keyword map |
| `{{strategy_recommendations}}` | Export strategy |
| `{{sources}}` | Source list |

### HTML Output

- Prefer the workspace sample `b2b-reports/Bao_cao_mau_Alibaba.html` as the concrete export template when available; otherwise use the reference `assets/templates/Gom_su_VietNam.html` as the base visual model for new industries.
- Use `Gom_su_VietNam.html` only as a reference sample unless the requested industry is ceramics.
- Create and save a `.html` file as the default final artifact.
- Do not finish with only a summary if an HTML report file can be created.
- Preserve responsiveness and print-friendly styling.
- Use charts only when verified data supports them.
- If Chart.js or JavaScript fails, keep all content in static HTML.
- If images are blocked or unavailable, continue without images and mark image data unavailable.

### DOCX Output

- Prefer a matched DOCX template when available.
- If no DOCX template exists, mirror the premium HTML report structure in a clean DOCX layout.
- Preserve paragraph styles, table styles, headers, footers, brand colors, and pagination when using a template.
- Keep source URLs in tables or footnotes.
- Use compact supplier, product, pricing, and keyword matrices.

---

## Part 5: Report Structure

For `full-intelligence-report`, include these sections unless the user's requested industry requires clearer renamed sections:

| Section | Purpose |
|---------|---------|
| Executive Summary | Top opportunities, risks, and recommended direction |
| Industry Scope | Product scope, target buyers, target markets |
| Market Overview | Demand signals and export context |
| Supplier Landscape | Alibaba suppliers and credibility comparison |
| Competitor Benchmark | Positioning, product range, MOQ, price, visuals |
| Pricing Intelligence | Price corridor, MOQ, unit caveats, confidence |
| Product Benchmark | Materials, use cases, customization, packaging |
| Factory Benchmark | Factory capability, certifications, export readiness |
| Image Benchmark | Listing image patterns and improvement ideas |
| SEO Keyword Map | Primary, long-tail, material/process, buyer-intent keywords |
| Buyer Persona | Importers, wholesalers, retailers, brands, hotels, distributors |
| Channel Strategy | Alibaba, RFQ, direct buyer outreach, sample strategy |
| Export Strategy | Positioning, product focus, Alibaba listing strategy, RFQ plan |
| Risk Analysis | Data gaps, compliance gaps, pricing risks, supplier risks |
| Source List | URLs and data quality notes |

Use Vietnamese for Vietnamese prompts, English for English prompts, and Chinese only when requested.

---

## Part 6: Compliance And Fallbacks

### Evidence Rules

| Rule | Instruction |
|------|-------------|
| No fake data | Never invent suppliers, URLs, certifications, prices, images, or product claims |
| Preserve originals | Keep company names, listing titles, URLs, certifications, MOQ, and prices exactly as found |
| Separate analysis | Clearly separate verified facts from recommendations and assumptions |
| Current data | Browse or verify when data may have changed |
| Source list | Include sources for supplier, product, pricing, and market claims |

### Fallback Policy

| Failure Case | Fallback |
|--------------|----------|
| Missing data | Mark `Unavailable` and explain |
| Thin data | Continue with verified evidence and lower confidence |
| No dedicated industry template | Use `assets/templates/Gom_su_VietNam.html` and adapt all industry content |
| Cannot write HTML file | Explain the blocker and provide complete HTML content |
| Charts unsupported | Replace with tables |
| Images unavailable | Continue without images |
| HTML failure | Produce simplified responsive HTML that follows the premium template |
| JavaScript failure | Disable interactions and preserve static content |
| Conflicting data | Show conflict, source URLs, and confidence level |

---

## Part 7: Final Quality Checklist

Before finalizing a report, verify:

- Requested industry is identified and named.
- A dynamic industry profile was created.
- Ceramics sample was used only as reference unless the requested industry is ceramics.
- A workspace sample (e.g., `b2b-reports/Bao_cao_mau_Alibaba.html`) or another suitable template was adapted to the requested industry.
- Full-intelligence mode is used unless the user asked otherwise.
- Premium-visual HTML is used unless the user asked otherwise.
- A physical `.html` file was created and its path is included in the final response.
- No generic B2B structure overrides industry-specific logic.
- Supplier names and URLs are real and preserved.
- Prices include the correct industry unit, MOQ, and caveats where visible.
- Certifications are relevant to the requested industry and not invented.
- Charts are backed by data.
- Missing data is marked `Unavailable`.
- Source list is included.
- Recommendations are actionable for Vietnam exporters or manufacturers in the requested industry.

## Completion Contract

The task is considered COMPLETE only when all conditions below are satisfied:

1. Industry research completed.
2. Market intelligence completed.
3. Competitor benchmark completed.
4. Pricing intelligence completed.
5. SEO mapping completed.
6. Executive recommendations completed.
7. Final HTML report generated.
8. HTML file saved successfully.
9. File path or downloadable artifact returned.

If steps 7-9 are missing, continue working automatically.

Never stop after research.
Never stop after analysis.
Never stop after recommendations.

The final deliverable is the HTML report.

Research alone does NOT satisfy task completion.